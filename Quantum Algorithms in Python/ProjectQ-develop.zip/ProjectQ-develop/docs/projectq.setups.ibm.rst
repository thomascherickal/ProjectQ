ibm
===

The IBM Setup imports the default IBM decomposition rules, compiler engines (featuring a CNOTMapper), and the IBM backend (IBMBackend).

Module contents
---------------

.. automodule:: projectq.setups.ibm
    :members:
    :special-members: __init__
    :imported-members:
